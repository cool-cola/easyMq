/**************************************************************************

DESC: ���������ݿ��ϣ��,�������IdxObj���key->blob

AUTHOR: nekeyzhong 

DATE: 2007��9��

PROJ: Part of MCP Project

 **************************************************************************/
/**************************************************************************
������Ŀ:
 g++ -g -DNODE_RESERVE_LEN=0 -DHASH_KEY_LEN=4 -DNODE_EXPIRE
 g++ -g -DNODE_RESERVE_LEN=0 -DHASH_KEY_LEN=16

 dd if=/dev/zero of=/data/aa bs=1024 count=1000
 dd if=/dev/zero of=/data/aa bs=1G count=1
 
 **************************************************************************/
#ifndef _DISKCACHE_HPP
#define _DISKCACHE_HPP

#include "IdxObjMng.hpp"
#include "Binlog.hpp"
#include "LockGuard.hpp"

//����TBucketNode������
ssize_t SetBucketNodeKey(void* pObj,void* pKey,ssize_t iKeyLen);
//��ȡTBucketNode������
ssize_t GetBucketNodeKey(void* pObj,void* pKey,ssize_t &iKeyLen);

class DiskCache
{
public:	

#pragma pack(1)
	typedef struct
	{
		char m_szKey[HASH_KEY_LEN];
		char m_cFlag;							//�������
		int32_t m_iLastUpdate;					//������ʱ��

#ifdef NODE_EXPIRE
		int32_t m_iExpireTime;
#endif
		char m_szReserve[NODE_RESERVE_LEN];		//���û�ʹ�õı�����
	}THashNode;
#pragma pack()

	typedef enum tagENodeWFlag
	{
		NODE_WFLAG_INVALID = 0x00,
		NODE_WFLAG_WRITING = 0x01,
		NODE_WFLAG_VALID   = 0x02
	} ENodeWFlag;

	enum
	{
		E_NO_DATA = -1000,
		E_BUFF_TOO_SMALL = -1001,	
		E_RESERVE_BUFF_SMALL = -1002,
		E_NO_HASH_SPACE = -1003,
		E_NO_OBJ_SPACE = -1004,
		E_ERROR = -1005,
		E_READING  = -1006,
		E_WRITTING = -1007,
		E_ERR_WRITE_BINLOG = -1008,
		E_INVALID  = -1009,
	};
	
	DiskCache();
	~DiskCache();

//-------------��ʼ����	-----------------	
	static size_t CountMemSize(ssize_t iBucketNum/*=0*/,size_t iHashNum/*=0*/,size_t FILESIZE,size_t iBlockSize=512);
	char* GetMemPtr(){return m_pMemPtr;}
	size_t GetBlockSize(){return m_stBuffObjMng.GetObjSize();}
	ssize_t AttachMemFile(char* pMemPtr,const size_t MEMSIZE, ssize_t iInitType,
				ssize_t iBucketNum/*=0*/,size_t iHashNum/*=0*/,
				char* pDiskFile,size_t iDiskFileStartPos/*=0*/,const size_t FILESIZE,size_t iBlockSize=512);

	/*
		DumpFile: dump�����ļ���
		pBinLogBaseName: binlog������
		iMaxBinLogSize: ����binlog�ļ����������
		iMaxBinLogNum:�ܵ�binlog�ļ������Ŀ
	*/
	ssize_t DumpInit(char *DumpFile="cache.dump",char * pBinLogBaseName="binlog_", ssize_t iMaxBinLogSize=50000000, 
						ssize_t iMaxBinLogNum=20);
	ssize_t StartUp();	
	ssize_t GetCurrBinLogSize(){return m_stBinLog.GetBinLogTotalSize();}

//-------------���ݲ���	(�ı�LRU)-----------------
	
	//node
	ssize_t GetNodeReserve(char szKey[HASH_KEY_LEN],char* pReserve,const ssize_t RESERVELEN=NODE_RESERVE_LEN);
	ssize_t SetNodeReserve(char szKey[HASH_KEY_LEN],char* pReserve,const ssize_t RESERVELEN=NODE_RESERVE_LEN);
	
	//data
	ssize_t Set(char szKey[HASH_KEY_LEN],char* szData,ssize_t iDataSize,char* pReserve=NULL,ssize_t iReserveLen=0);
	ssize_t SetNoLock(char szKey[HASH_KEY_LEN],char* szData,ssize_t iDataSize,char* pReserve=NULL,ssize_t iReserveLen=0);
	ssize_t Get(char szKey[HASH_KEY_LEN],char* szData,const ssize_t DATASIZE,char* pReserve=NULL,const ssize_t RESERVELEN=NODE_RESERVE_LEN);	
	ssize_t GetNoLockNoLRU(char szKey[HASH_KEY_LEN],char* szData,const ssize_t DATASIZE,char* pReserve=NULL,const ssize_t RESERVELEN=NODE_RESERVE_LEN);
	ssize_t Del(char szKey[HASH_KEY_LEN]);
	ssize_t DelNoLock(char szKey[HASH_KEY_LEN]);

	//�ڵ��������,�ο�Print����
	CHashTab* GetBucketHashTab() {return &m_stBucketHashTab;}
	CBuffMng* GetBuffMng() {return &m_stBuffMng;}

//-------------���Բ���	(���ı�LRU)-----------------
	ssize_t GetDataSize(char szKey[HASH_KEY_LEN]);
	ssize_t GetNode(char szKey[HASH_KEY_LEN],THashNode *pHashNode);	
#ifdef NODE_EXPIRE
	ssize_t SetExpireTime(char szKey[HASH_KEY_LEN],int32_t iExpireTime);
#endif	

	void LockCache();
	void UnLockCache();	

	//������	
	ssize_t GetUsage(ssize_t &iBucketNum,ssize_t &iUsedBucket,
							ssize_t &iHashNodeUsed,ssize_t &iHashNodeCount,
							ssize_t &iObjNodeUsed,ssize_t &iObjNodeCount);
	ssize_t GetOldestNode(THashNode* pHashNode);
	void Print(FILE *fpOut);
	//������δ��֪ʱ��,������time(NULL),����ʹ�������֪��ʱ��,(��ʼ��Ϊ0)
	void SetTimeNow(int32_t iTimeNow){m_iTimeNow = iTimeNow;}

	//����	
	ssize_t CoreDump();
	ssize_t CoreDumpNoLock();
	CBinLog* GetBinLog(){return &m_stBinLog;}

	ssize_t _WriteNodeLog(ssize_t iOp,THashNode* pHashNode,ssize_t iDataSize);
	ssize_t _Del(THashNode* pHashNode);	

private:	
	ssize_t _CoreDump();
	ssize_t _CoreRecover();
	ssize_t _Set(THashNode* pHashNode,ssize_t iDataSize);

private:
	int32_t m_iTimeNow;

	char *m_pMemPtr;
	ssize_t m_iMemSize;
	
	typedef struct
	{
		int32_t m_iDataOK;			//�����Ƿ�һ��
	}TMemCacheHead;

	TMemCacheHead* m_pMemCacheHead;
	
	//ͷ����ϣ
	CHashTab m_stBucketHashTab;	
	TIdxObjMng m_stHashObjMng;

	//LRU��̭��
	CObjQueue m_stLRUQueue;

	//��ʵ���ݿռ�
	CBuffMng m_stBuffMng;	
	TDiskIdxObjMng m_stBuffObjMng;	

	//��������־
	CBinLog m_stBinLog;

	//��ʱ����
	ssize_t m_iInitType;

	char m_szDumpFile[256];

	static const ssize_t BUFFSIZE = 32*1024*1024;
	char* m_pBuffer;

	pthread_mutex_t m_MutexLock;
};

#endif	/*_MEMCACHE_HPP*/
