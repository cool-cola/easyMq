/**************************************************************************

DESC: ����ʽ������key->block1->block2->block3...

AUTHOR: nekeyzhong 

DATE: 2008��1��

PROJ: Part of MCP Project

Set/Get 1024�ֽڲ���:
 **************************************************************************/ 
 /**************************************************************************
������Ŀ:
_HASH_LONG_KEY16	16�ֽڳ���key
_HASH_LONG_KEY32	32�ֽڳ���key(Ĭ��4�ֽ�)

_HASH_NODE_DIRTY	֧��������
HASH_NODE_RESERVE_LEN	����ڵ��ڱ����ֶγ���
 **************************************************************************/
#ifndef _NODECACHE_HPP
#define _NODECACHE_HPP

#include "IdxObjMng.hpp"
#include "BinlogNR.hpp"

#ifndef HASH_NODE_RESERVE_LEN
#define HASH_NODE_RESERVE_LEN		0
#endif

//����TBucketNode������
ssize_t SetBucketNodeKey(void* pObj,void* pKey,ssize_t iKeyLen);
//��ȡTBucketNode������
ssize_t GetBucketNodeKey(void* pObj,void* pKey,ssize_t &iKeyLen);

//match return 0
typedef ssize_t (*DUMP_MATCH_FUNC)(void* pHashNode,void* pArg);

class NodeCache
{
public:	
#ifdef _HASH_LONG_KEY16
	const static ssize_t HASH_KEY_LEN=16;
#elif  _HASH_LONG_KEY32
	const static ssize_t HASH_KEY_LEN=32;
#else
	const static ssize_t HASH_KEY_LEN= 4;
#endif

	typedef struct
	{
		char m_szKey[HASH_KEY_LEN];

#ifdef _HASH_NODE_DIRTY		
		ssize_t m_iFlag;
#endif

	//������
	char m_szReserve[HASH_NODE_RESERVE_LEN];

	}THashNode;

	enum
	{
		F_DATA_CLEAN = 0,
		F_DATA_DIRTY = 1,
	};

	enum
	{
		DUMP_TYPE_MIRROR,
		DUMP_TYPE_NODE,
#ifdef _HASH_NODE_DIRTY		
		DUMP_TYPE_DIRTY_NODE,
#endif		
	};
	
	enum
	{
		E_PAGE_NO_DATA = -1000,
		E_BUFF_TOO_SMALL = -1001,	
		E_NO_HASH_SPACE = -1002,
		E_NO_OBJ_SPACE = -1003,
	};

	NodeCache();
	~NodeCache();

	//��ʼ
	static ssize_t CountBaseSize(ssize_t iHashNum,ssize_t iBlockSize=512);
	char* GetMemPtr(){return m_pMemPtr;}
	ssize_t GetBlockSize(){return m_stBlockObjMng.GetObjSize();}
	
	//���ڴ�,iBlockSize=0��ʾ����Ҫ������
	ssize_t AttachMem(char* pMemPtr,const ssize_t MEMSIZE,ssize_t iHashNum,ssize_t iInitType=emInit,ssize_t iBlockSize=512);

	/*
		iDumpMin: dump��ʱ����(min),0��ʾ��������Ч
		DumpFile: dump�����ļ���
		iDumpType: dump������
		iBinLogOpen: �Ƿ��binlog
		pBinLogBaseName: binlog������
		iMaxBinLogSize: ����binlog�ļ����������
		iMaxBinLogNum:�ܵ�binlog�ļ������Ŀ
	*/	
	ssize_t DumpInit(ssize_t iDumpMin,
				char *DumpFile="cache.dump",
				ssize_t iDumpType=DUMP_TYPE_NODE,
				ssize_t iBinLogOpen=0,
				char * pBinLogBaseName="binlog",
				ssize_t iMaxBinLogSize=20000000,
				ssize_t iMaxBinLogNum=20,
				ssize_t iBinlogCommitSecs=0);
	ssize_t StartUp();	
	ssize_t TimeTick(time_t iNow=0);//ѭ������,dump

	//node�ڵ����
	ssize_t GetNodeFlg(char szKey[HASH_KEY_LEN]);
	ssize_t SetNodeFlg(char szKey[HASH_KEY_LEN],ssize_t iFlag);
	char* GetReserve(char szKey[HASH_KEY_LEN]);
	ssize_t SetReserve(char szKey[HASH_KEY_LEN],char* pReserve,ssize_t iReserveLen);	
	
	//block�����
	ssize_t Set(char szKey[HASH_KEY_LEN],char* pBlockBuffer,ssize_t iBufferLen,
				ssize_t iDataFlag=F_DATA_DIRTY,char* pReserve=NULL,ssize_t iReserveLen=0);
	ssize_t Del(char szKey[HASH_KEY_LEN]);	
	ssize_t SelectBlock(char szKey[HASH_KEY_LEN],char* pBuffer,const ssize_t iBUFFSIZE,BLOCK_SELECT_FUNC fBlockSelectFunc=NULL,void* pSelectArg=NULL,ssize_t iStartBlockPos=0,ssize_t iBlockNum=-1);	
	ssize_t FindBlock(char szKey[HASH_KEY_LEN],BLOCK_FIND_EQU_FUNC fFindEquFunc,void* pFindArg=NULL);	
	ssize_t AppendBlock(char szKey[HASH_KEY_LEN],char* pBlockData,ssize_t iDataFlag=F_DATA_DIRTY);
	ssize_t InsertBlock(char szKey[HASH_KEY_LEN],char* pBlockData,ssize_t iInsertPos=0,ssize_t iDataFlag=F_DATA_DIRTY);
	ssize_t DeleteBlock(char szKey[HASH_KEY_LEN],BLOCK_DEL_EQU_FUNC fDelEquFunc,void* pDeleteArg=NULL);
	ssize_t DeleteBlock(char szKey[HASH_KEY_LEN],ssize_t iPos);
	ssize_t TrimTail(char szKey[HASH_KEY_LEN],ssize_t iBlockNum);

	//�ڵ��������
	CHashTab* GetBucketHashTab() {return &m_stBucketHashTab;}
		
	//���Բ���
	ssize_t GetBlockObjSize();
	ssize_t GetBlockNum(char szKey[HASH_KEY_LEN]);
	char* GetBlockData(char szKey[HASH_KEY_LEN],ssize_t iPos);

	char* GetFirstBlockData(char szKey[HASH_KEY_LEN]);
	/*
	ͨ��ָ��λ��ƫ�Ƽ�������λ��,�õ���һ���ڵ�,
	pBlockData������ԭʼλ��
	*/
	char* GetNextBlockData(char* pBlockData);
	ssize_t GetBlockPos(char szKey[HASH_KEY_LEN],char* pBlockData);

	//������
	ssize_t GetUsage(ssize_t &iHashUsed,ssize_t &iHashCount,ssize_t &iBlockUsed,ssize_t &iBlockCount);
	THashNode* GetOldestNode();
	void Print(FILE *fpOut);

	//Ǩ��ʹ��
	ssize_t CoreDumpMem(char* pBuffer,const ssize_t BUFFSIZE,DUMP_MATCH_FUNC fDumpMatchFunc,void* pArg);
	ssize_t CoreRecoverMem(char* pBuffer,ssize_t iBufferSize);
	ssize_t CleanNode(DUMP_MATCH_FUNC fMatchFunc,void* pArg);

	//����
	ssize_t CoreDump();	
	
private:	
	ssize_t _WriteNodeLog(char szKey[HASH_KEY_LEN]);
	ssize_t _WriteDataLog(char szKey[HASH_KEY_LEN],char* pBuffer=NULL,ssize_t iBufferSize=0);
	
	ssize_t _CoreDump(ssize_t iType);
	ssize_t _CoreRecover(ssize_t iType);

	THashNode* _GetHashNode(char szKey[HASH_KEY_LEN]);
	ssize_t _AppendBlock(char szKey[HASH_KEY_LEN],char* pBlockData);
	ssize_t _InsertBlock(char szKey[HASH_KEY_LEN],char* pBlockData,ssize_t iInsertPos);
	ssize_t _Del(char szKey[HASH_KEY_LEN]);
	ssize_t _Set(THashNode* pHashNode,char* pBlockBuffer,ssize_t iBufferLen);
	ssize_t _Set(char szKey[HASH_KEY_LEN],char* pBlockBuffer,ssize_t iBufferLen);
	ssize_t _DeleteBlock(char szKey[HASH_KEY_LEN],ssize_t iPos);
	ssize_t _TrimTail(char szKey[HASH_KEY_LEN],ssize_t iBlockNum);
	ssize_t _SetAttribute(char szKey[HASH_KEY_LEN],char* pAttribute,const ssize_t iAttributeLen);
private:	

	char *m_pMemPtr;
	ssize_t m_iMemSize;
	ssize_t m_iDumpType;
	
	typedef struct
	{
		time_t m_tLastDumpTime;
	}TNodeCacheHead;

	TNodeCacheHead* m_pNodeCacheHead;
 
	//ͷ����ϣ
	TIdxObjMng m_stHashObjMng;
	CHashTab m_stBucketHashTab;
	
	//LRU��̭��
	CObjQueue m_stLRUQueue;

	//��ʵ���ݿռ�
	TIdxObjMng m_stBlockObjMng;	
	CBlockMng m_stBlockMng;

	ssize_t m_iInitType;
	
	//��������־
	CBinLog m_stBinLog;
	ssize_t m_iBinLogOpen;
	ssize_t m_iDumpMin;
	char m_szDumpFile[256];
	ssize_t m_iTotalBinLogSize;
	ssize_t m_iBinlogCommitSecs;
	time_t m_tLastRefreshTime;

	//����ʹ�õ�buffer
	static const ssize_t BUFFSIZE = 32*1024*1024;
	char* m_pBuffer;
};

#endif	/*_MEMCACHE_HPP*/
