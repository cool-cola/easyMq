/*************************************************************
Copyright (C), 1988-1999
Author:nekeyzhong
Version :1.0
Date: 2006-09
Description: �ڴ����ݴ���ܵ�, -lpthread

CodeQueueMutil: ��װCodeQueueʵ�ֵĶ�ܵ���

***********************************************************/

#ifndef _MEMQUEUEMUTIL_HPP
#define _MEMQUEUEMUTIL_HPP

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <assert.h>

#include "CodeQueue.hpp"

#define MAX_CODE_QUEUE_NUMBER	26

class CCodeQueueMutil
{
public:
	static int CreateMQByFile(char* szMQFile, CCodeQueueMutil* pCodeQueueMutil);
	
	CCodeQueueMutil();
	~CCodeQueueMutil();
	
	int GetCodeLength();
	int GetSize();
	int WaitData(struct timeval *pTimeval);
	
	int AddToSelectFD(fd_set *pReadFD);
	int ClearSelectFD(fd_set *pReadFD);

	bool IsQueueEmpty();
	inline bool IsQueueFull();
	void Print(FILE* fp = stdout);

	CCodeQueue* GetCodeQueue(short sCQID);
	int GetCodeQueueNum();

	int GetWLock(short sCQID=0){return m_apCodeQueue[sCQID]->GetWLock();};
	int GetRLock(short sCQID=0){return m_apCodeQueue[sCQID]->GetRLock();};
	

	int AppendOneCode(short sCQID,const char *pInCode, int iInLength,bool bAutoNotify=true);
	int GetHeadCode(short &sCQID,char *pOutCode, int *piOutLength);
	/*************************************************
	����4����������1��1ͨ��ʱ��ʹ�ã��������ھ���ģʽ��
	��Ŀ�����ڱ����û���CQ֮������ݿ����������˼������ֻ����ָ��
	*************************************************/	
	int GetAppendPtr(short sCQID,char *&pInCode, int *iInLength);
	int AppendCodePtr(short sCQID,int iCodeLength);
	
	int GetHeadCodePtr(short &sCQID,char *&pOutCode, int *piOutLength);
	int SkipHeadCodePtr(short sCQID);

#if 0
	//���ܵ����ݽӿ�
	int AppendOneCode(const char *pInCode, int iInLength,bool bAutoNotify=true)
	{return AppendOneCode(0,pInCode,iInLength,bAutoNotify);}
	int GetHeadCode(char *pOutCode, int *piOutLength)
	{return GetHeadCode(0,pOutCode,piOutLength);}
	int GetAppendPtr(char *&pInCode, int *iInLength)
	{return GetAppendPtr(0,pInCode,iInLength);}
	int AppendCodePtr(int iCodeLength)
	{return AppendCodePtr(0,iCodeLength);}
	int GetHeadCodePtr(char *&pOutCode, int *piOutLength)
	{return GetHeadCodePtr(0,pOutCode,piOutLength);}
	int SkipHeadCodePtr()
	{return SkipHeadCodePtr(0);}
#endif

private:
	CCodeQueue* m_apCodeQueue[MAX_CODE_QUEUE_NUMBER];

	//�ܵ�����
	int	m_iCQNumber;
	
	//��ѡ�ܵ�ѭ��
	int m_iStartCQID;
};

#endif  /* _MEMQUEUE_HPP */


