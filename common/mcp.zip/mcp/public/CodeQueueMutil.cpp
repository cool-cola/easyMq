/******************************************************************************
 * CodeQueue.cpp
 * 
 * Copyright 2000-2008 TENCENT.Ltd.
 * 
 * DESCRIPTION: - 
 *     ��������
 * --------------------
 * 2006��8��25��, nekeyzhong 

 ******************************************************************************/
#include "CodeQueueMutil.hpp"

/*************************************************
Description:	
���ݹܵ��ļ������ܵ�

Input:	szMQFile,pCodeQueueMutil
Output:	��
Return:	<0����,=0�ɹ�
*************************************************/
int CCodeQueueMutil::CreateMQByFile(char* szMQFile, CCodeQueueMutil* pCodeQueueMutil)
{
	if (!pCodeQueueMutil)
	{
		return -1;
	}

	//get cofig from mq file
	TCQCfgStruct stCQCfgStruct;
	char szFifoPath[MAX_CQCONF_VAL_SIZE] = {0};
	int iRet = CCodeQueue::GetMQCfgFromFile(szMQFile,stCQCfgStruct,szFifoPath);
	if (iRet < 0)
	{
		printf("GetMQFromFile %s failed!\n",szMQFile);
		return -2;	
	}

	int iShmSize = stCQCfgStruct.iShmSize;
	int iWlock = stCQCfgStruct.iWlock;
	int iRlock = stCQCfgStruct.iRlock;
	int iNumber = stCQCfgStruct.iNumber;
	
	if(iNumber <= 0 || iNumber > MAX_CODE_QUEUE_NUMBER)
	{
		printf("[%s:%d]%s iNumber %d value error!\n",__FILE__,__LINE__,szMQFile,iNumber);
		return -4;
	}
	
	if(iShmSize <= 0)
	{
		printf("[%s:%d]%s Size %d value error!\n",__FILE__,__LINE__,szMQFile,iShmSize);
		return -4;
	}

	//create shm for mq
	key_t iShmKeyQ = CCodeQueue::FTOK(szMQFile,'Q');
	if (iShmKeyQ < 0)
	{
		printf("[%s:%d]CCodeQueue::FTOK %s for iShmKeyQ failed!\n",__FILE__,__LINE__,szMQFile);
		return -5;
	}
	
	int iErrorNo = 0;
	bool bShmNewCreate = false;
	int iOutShmID;
	char *pShmMemQ = CCodeQueue::CreateMQShm(iShmKeyQ,iShmSize*iNumber,iErrorNo,bShmNewCreate,iOutShmID);
	if (!pShmMemQ)
	{
		printf("Create Shm failed! ErrorNo=%d, ERR=%s\n",iErrorNo,strerror(iErrorNo));
		return -2;
	}

	char *pWLockMem = NULL;
	bool bLockNewCreate;
	int iWLockSize = 0;
	if(iWlock == CCodeQueue::emSpinLock)
	{
		iWLockSize = sizeof(spinlock_t);
			
		key_t iShmKeyW = CCodeQueue::FTOK(szMQFile,'S');
		if (iShmKeyW < 0)
		{
			printf("[%s:%d]CCodeQueue::FTOK %s fro iShmKey failed!\n",__FILE__,__LINE__,szMQFile);
			return -6;
		}	
		
		pWLockMem = (char*)shm_spin_lock_init(iShmKeyW,iNumber);
		if(!pWLockMem)
		{
			printf("ERR: create w spin_lock failed.\n");
			return -4;
		}	
	}
	else if(iWlock == CCodeQueue::emPthreadMutexLock)
	{
		iWLockSize = sizeof(pthread_mutex_t);
		
		key_t iShmKeyW = CCodeQueue::FTOK(szMQFile,'M');
		if (iShmKeyW < 0)
		{
			printf("[%s:%d]CCodeQueue::FTOK %s fro iShmKey failed!\n",__FILE__,__LINE__,szMQFile);
			return -6;
		}	
		
		pWLockMem = CCodeQueue::CreateMQShm(iShmKeyW,sizeof(pthread_mutex_t)*iNumber,iErrorNo,bLockNewCreate,iOutShmID);
		if(!pWLockMem)
		{
			printf("Create Shm for PthreadMutexLock failed! ErrorNo=%d, ERR=%s\n",iErrorNo,strerror(iErrorNo));
			return -2;
		}

	    pthread_mutexattr_t mattr;
	    pthread_mutexattr_init(&mattr);
	    pthread_mutexattr_setpshared(&mattr,PTHREAD_PROCESS_SHARED);
			
		struct shmid_ds s_ds;
		shmctl(iOutShmID,IPC_STAT,&s_ds);
		int iAttach = s_ds.shm_nattch;

		if((iAttach==1) || bLockNewCreate)
		{
			for(int i=0; i<iNumber; i++)
			{
				pthread_mutex_t *pstMutexW = (pthread_mutex_t*)(pWLockMem+sizeof(pthread_mutex_t)*i);
				pthread_mutex_init(pstMutexW,&mattr);
			}		
		}	
	}
	//no w lock
	else
	{
		;
	}

	//r lock
	char *pRLockMem = NULL;
	int iRLockSize = 0;
	if(iRlock == CCodeQueue::emSpinLock)
	{
		iRLockSize = sizeof(spinlock_t);
		
		key_t iShmKeyR = CCodeQueue::FTOK(szMQFile,'s');
		if (iShmKeyR < 0)
		{
			printf("[%s:%d]CCodeQueue::FTOK %s fro iShmKey failed!\n",__FILE__,__LINE__,szMQFile);
			return -6;
		}	

		pRLockMem = (char*)shm_spin_lock_init(iShmKeyR,iNumber);
		if(!pRLockMem)
		{
			printf("ERR: create r spin_lock failed.\n");
			return -4;
		}
	}
	else if(iRlock == CCodeQueue::emPthreadMutexLock)
	{
		iRLockSize = sizeof(pthread_mutex_t);
		
		key_t iShmKeyR = CCodeQueue::FTOK(szMQFile,'m');
		if (iShmKeyR < 0)
		{
			printf("[%s:%d]CCodeQueue::FTOK %s fro iShmKey failed!\n",__FILE__,__LINE__,szMQFile);
			return -6;
		}	
		
		pRLockMem = CCodeQueue::CreateMQShm(iShmKeyR,sizeof(pthread_mutex_t)*iNumber,iErrorNo,bLockNewCreate,iOutShmID);
		if(!pRLockMem)
		{
			printf("Create Shm for PthreadMutexLock failed! ErrorNo=%d, ERR=%s\n",iErrorNo,strerror(iErrorNo));
			return -2;
		}

	    pthread_mutexattr_t mattr;
	    pthread_mutexattr_init(&mattr);
	    pthread_mutexattr_setpshared(&mattr,PTHREAD_PROCESS_SHARED);
			
		struct shmid_ds s_ds;
		shmctl(iOutShmID,IPC_STAT,&s_ds);
		int iAttach = s_ds.shm_nattch;

		if((iAttach==1) || bLockNewCreate)
		{
			for(int i=0; i<iNumber; i++)
			{
				pthread_mutex_t *pstMutexR = (pthread_mutex_t*)(pRLockMem+sizeof(pthread_mutex_t)*i);
				pthread_mutex_init(pstMutexR,&mattr);
			}		
		}	
	}
	//no r lock
	else
	{
		;
	}

	for(int i=0; i<iNumber; i++)
	{
		pCodeQueueMutil->m_apCodeQueue[i] = new CCodeQueue();
		pCodeQueueMutil->m_apCodeQueue[i]->SetID(i);

		char *pWLock = (char*)pWLockMem + iWLockSize*i;
		char *pRLock = (char*)pRLockMem + iRLockSize*i;
		if (pCodeQueueMutil->m_apCodeQueue[i]->AttachMem(iShmKeyQ,pShmMemQ+i*iShmSize,iShmSize,
					bShmNewCreate?CCodeQueue::Init:CCodeQueue::Recover,
					iWlock,iRlock,(void*)pWLock,(void*)pRLock,szFifoPath))
		{
			printf("Call AttachMem failed!\n");
			return -3;
		}
	}

	pCodeQueueMutil->m_iCQNumber = iNumber;

	if (bShmNewCreate)
		printf("Create New Pipe Success,Key:%p,Size:%d x %d,WLock %d,RLock %d\n",
				(void*)iShmKeyQ,iShmSize,iNumber,iWlock,iRlock);
	else
		printf("Attach To Pipe Success,Key:%p,Size:%d x %d,WLock %d,RLock %d\n",
				(void*)iShmKeyQ,iShmSize,iNumber,iWlock,iRlock);	
	printf("%s ",szMQFile);	
	return 0;
}

CCodeQueueMutil::CCodeQueueMutil()
{
	memset(m_apCodeQueue,0,sizeof(m_apCodeQueue));
	m_iStartCQID = 0;
	m_iCQNumber = 0;
}

CCodeQueueMutil::~CCodeQueueMutil()
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		if(!m_apCodeQueue[i])
			break;

		delete m_apCodeQueue[i];
		m_apCodeQueue[i] = NULL;
	}
}


/*************************************************
Return:	�����ܳ���
*************************************************/
int CCodeQueueMutil::GetCodeLength()
{
	int iAllLen = 0;
	for(int i=0; i<m_iCQNumber; i++)
	{
		iAllLen += m_apCodeQueue[i]->GetCodeLength();
	}
	
	return iAllLen;
}

/*************************************************
Return:	�ܵ��ܳ���
*************************************************/
int CCodeQueueMutil::GetSize()
{
	int iAllSize = 0;
	for(int i=0; i<m_iCQNumber; i++)
	{
		iAllSize += m_apCodeQueue[i]->GetSize();
	}
	
	return iAllSize;
}
bool CCodeQueueMutil::IsQueueEmpty()
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		if(!m_apCodeQueue[i]->IsQueueEmpty())
			return false;
	}
	return true;
}
bool CCodeQueueMutil::IsQueueFull()
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		if(!m_apCodeQueue[i]->IsQueueFull())
			return false;
	}
	return true;
}

CCodeQueue* CCodeQueueMutil::GetCodeQueue(short sCQID)
{
	if(sCQID >= m_iCQNumber || sCQID < 0)
		return NULL;
	
	if(!m_apCodeQueue[sCQID])
		return NULL;
	
	return m_apCodeQueue[sCQID];
}
int CCodeQueueMutil::GetCodeQueueNum()
{
	return m_iCQNumber;
}
int CCodeQueueMutil::AddToSelectFD(fd_set *pReadFD)
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		m_apCodeQueue[i]->AddToSelectFD(pReadFD);
	}	
	return 0;
}
int CCodeQueueMutil::ClearSelectFD(fd_set *pReadFD)
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		m_apCodeQueue[i]->ClearSelectFD(pReadFD);
	}	
	return 0;
}
int CCodeQueueMutil::WaitData(struct timeval *pTimeval)
{
	fd_set ReadFD;
	FD_ZERO(&ReadFD);
	char szTempBuf[1024];	

	for(int i=0; i<m_iCQNumber; i++)
	{
		int iFD = m_apCodeQueue[i]->GetReadNotifyFD();
		if(iFD >= 0)
			FD_SET(iFD, &ReadFD);
	}

	int iRet = select(FD_SETSIZE, &ReadFD, NULL, NULL, pTimeval);
	if(iRet > 0)
	{
		for(int i=0; i<m_iCQNumber; i++)
		{
			int iFD = m_apCodeQueue[i]->GetReadNotifyFD();
			if(FD_ISSET(iFD, &ReadFD))
			{
				read(iFD, szTempBuf,sizeof(szTempBuf));
			}
		}	
	}

	return iRet>=0?iRet:0;
}

/*************************************************
Description:	
׷�����ݣ����ݳ�ʼ��ѡ��������ⷽʽ

Input:	pInCode,iInLength,bAutoNotify:�Ƿ��Զ�������Ϣ֪ͨ,�������е���SendNotify()
Output:	��
Return:	!=0����,=0�ɹ�
*************************************************/
int CCodeQueueMutil::AppendOneCode(short sCQID,const char *pInCode, int iInLength,bool bAutoNotify/*=true*/)
{
	if(!m_apCodeQueue[sCQID])
		return -1;
	
	int iRet = m_apCodeQueue[sCQID]->AppendOneCode(pInCode,iInLength,bAutoNotify);
	return iRet>0?0:iRet;
}

/*************************************************
Description:	
��ȡ���ݣ����ݳ�ʼ��ѡ��������ⷽʽ

Input:	����������λ��pOutCode�ͻ�������󳤶�piOutLength
Output:	ʵ�����ݳ���piOutLength
Return:	!=0����,=0�ɹ�
*************************************************/	
int CCodeQueueMutil::GetHeadCode(short &sCQID,char *pOutCode, int *piOutLength)
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		m_iStartCQID++;
		m_iStartCQID = m_iStartCQID%m_iCQNumber;	
		
		int iOutLength = *piOutLength;
		int iRet = m_apCodeQueue[m_iStartCQID]->GetHeadCode(pOutCode,&iOutLength);
		if(iRet == 0)
		{
			sCQID = (short)m_iStartCQID;
			*piOutLength = iOutLength;
			return iRet;
		}
	}
	return -1;
}

/*************************************************
Description:	
��ӡ�ܵ����ݣ�����ʱʹ��

Input:	�����
Output:	��
*************************************************/
void CCodeQueueMutil::Print(FILE* fp)
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		if(!m_apCodeQueue[i])
			break;

		fprintf(fp,"\n\nCQ %d:",i);
		m_apCodeQueue[i]->Print(fp);
	}
}

/*************************************************
Description:	
��ȡ��ֱ��׷�����ݵ�λ��ָ��ͳ��ȣ����û�ֱ�ӿ������ݣ�
�ɱ���һ�����ݿ���������ռ��������������ʹ���Ϲ����鷳

Input:	��
Output:	����λ��ָ��Ϳ��ó���
Return:	<0����=0�ɹ�
*************************************************/
int CCodeQueueMutil::GetAppendPtr(short sCQID,char *&pInCode, int *iInLength)
{
	if(!m_apCodeQueue[sCQID])
		return -1;
	
	return m_apCodeQueue[sCQID]->GetAppendPtr(pInCode,iInLength);
}

/*************************************************
Description:	
�û�ʹ��GetAppendPtr��ȡ�����ռ䲢�������ݺ󣬵��ô˺�������CQ���ݵĳ���

Input:	iCodeLength ���ݳ���
Output:	��
Return:	<0����=0�ɹ�
*************************************************/
int CCodeQueueMutil::AppendCodePtr(short sCQID,int iCodeLength)
{
	if(!m_apCodeQueue[sCQID])
		return -1;

	return m_apCodeQueue[sCQID]->AppendCodePtr(iCodeLength);
}

/*************************************************
Description:	
��ȡ��һ�����ݵ�λ��ָ��ͳ��ȣ�֮������û�ֱ�ӽ������ݣ�
�ɱ���һ�����ݿ���������ռ���������������û��޷�ʹ��

Input:	��
Output:	pOutCode ��������λ�ã�piOutLength �������ݳ���
Return:	�ظ�piOutLength���ȷ��أ�<0�����ݵ��޷��ó���=0������
*************************************************/
int CCodeQueueMutil::GetHeadCodePtr(short &sCQID,char *&pOutCode, int *piOutLength)
{
	for(int i=0; i<m_iCQNumber; i++)
	{
		m_iStartCQID++;
		m_iStartCQID = m_iStartCQID%m_iCQNumber;	
		
		int iRet = m_apCodeQueue[m_iStartCQID]->GetHeadCodePtr(pOutCode,piOutLength);
		if(iRet > 0)
		{
			sCQID = (short)m_iStartCQID;
			return iRet;
		}	
		else if(iRet < 0)
		{
			m_iStartCQID--;
			if(m_iStartCQID < 0 )
				m_iStartCQID = m_iCQNumber-1;
			
			return iRet;
		}	
	}
	return 0;
}

/*************************************************
Description:	
ʹ��GetHeadCodePtr��õ�ǰ����λ�ò�������Ϻ󣬸���CQ����������

Input:	��
Output:	��
Return:	<0����=0�ɹ�
*************************************************/
int CCodeQueueMutil::SkipHeadCodePtr(short sCQID)
{
	if(!m_apCodeQueue[sCQID])
		return -1;

	return m_apCodeQueue[sCQID]->SkipHeadCodePtr();
}

#if 0
#include <stdio.h>
#include <sys/time.h>

int main(int argc ,char **argv)
{
	CCodeQueueMutil stQueue;
	CCodeQueueMutil::CreateMQByFile("mq_test.conf",&stQueue);
	
	timeval t1,t2;
	gettimeofday(&t1,NULL);
	char ss[2000];
	memset(ss,'c',2000);
	char ss2[2000];
	unsigned size = 2000;
	int datalen = 0;
	int perlen = 5;
	int cnt = 1000000;
	for (int i=0;; i++)
	{
		stQueue.AppendOneCode(0,ss,perlen);
		stQueue.AppendOneCode(0,ss,perlen);
		stQueue.AppendOneCode(0,ss,perlen);
		stQueue.AppendOneCode(1,ss,perlen);
		stQueue.AppendOneCode(2,ss,perlen);

		//stQueue.Print(stdout);
		printf("emtpy %d,",(int)stQueue.IsQueueEmpty());
		printf("full %d,",(int)stQueue.IsQueueFull());
		printf("size %d,",(int)stQueue.GetSize());
		printf("len %d,",(int)stQueue.GetCodeLength());
		
		while(1)
		{
			short cq;
			datalen = 2000;
			int iRet = stQueue.GetHeadCode(cq,(char*)ss2,&datalen);
			if(iRet != 0)
				break;
			
			if(perlen != datalen)
			{
				printf("bad len\n");
				return -1;
			}
			if( 0 != memcmp(ss,ss2,perlen))
			{
				printf("bad data\n");
				return -1;
			}
			printf("get from %d",(int)cq);
		}

		break;
	}
		printf("emtpy %d,",(int)stQueue.IsQueueEmpty());
		printf("full %d,",(int)stQueue.IsQueueFull());
		printf("size %d,",(int)stQueue.GetSize());
		printf("len %d,",(int)stQueue.GetCodeLength());

	stQueue.Print(stdout);
	
/*

	gettimeofday(&t1,NULL);
	for (int i=0; i<1000000; i++)
	{
		char* pAppPtr;
		int iAppLen = 0;
		if(stQueue.GetAppendPtr(pAppPtr,&iAppLen))
		{
			if(stQueue.AppendOneCode(ss,200))
				printf("ffffffff\n");		
		}
		else if(iAppLen < 2000)
		{
			if(stQueue.AppendOneCode(ss,200))
				printf("ffffffff\n");			
		}
		else
		{
			memcpy(pAppPtr,ss,datalen);
			stQueue.AppendCodePtr(datalen);
		}

		//-----
		if(stQueue.GetHeadCodePtr(pAppPtr,&iAppLen))
		{
			datalen = 2000;
			if(stQueue.GetHeadCode((char*)ss,&datalen))	
				printf("bbbbb\n");
		}
		else
		{
			memcpy(ss,pAppPtr,iAppLen);
			stQueue.SkipHeadCodePtr();
		}
			
	}
	gettimeofday(&t2,NULL);
	sp = (t2.tv_sec-t1.tv_sec)*1000 + (t2.tv_usec-t1.tv_usec)/1000;
	printf("sp = %d,cnt 1000000\n",sp);
*/	
	return 0;
}

#endif


