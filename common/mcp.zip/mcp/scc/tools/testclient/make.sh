g++ -g clitest.cpp -o echosvr ../../public/TSocket.cpp  ../../public/Base.cpp -I../../public/
g++ -g udpclient.cpp -o echoudpsvr ../../public/Base.cpp -I../../public/

